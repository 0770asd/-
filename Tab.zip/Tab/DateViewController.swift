//
//  ViewController.swift
//  DatePicker
//
//  Created by 203a17 on 2022/04/08.
//

import UIKit

class DateViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    let MAX_ARRAY_NUM = 10
    let PICKER_VIEW_COLUMN = 2
    let PICKER_VIEW_HEIGHT:CGFloat = 150
    var imageArray = [UIImage?]()
    var imageFileName = ["1.jpeg", "2.png", "3.jpeg", "4.jpeg", "5.jpeg",
                         "6.jpeg", "7.jpeg", "8.jpeg", "9.jpeg", "10.jpeg"]
    
    @IBOutlet var 피커뷰: UIPickerView!
    @IBOutlet var 아이템: UILabel!
    @IBOutlet var 이미지뷰: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        for i in 0 ..< MAX_ARRAY_NUM {
            let image = UIImage(named: imageFileName[i])
            imageArray.append(image)
        }
        
        아이템.text = imageFileName[0]
        이미지뷰.image = imageArray[0]
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return PICKER_VIEW_COLUMN
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return PICKER_VIEW_HEIGHT
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return imageFileName.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return imageFileName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let 이미지뷰 = UIImageView(image: imageArray[row])
        이미지뷰.frame = CGRect(x: 0, y: 0, width: 100, height: 150)
        
        return 이미지뷰
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (component==0) {
            아이템.text = imageFileName[row]
        }
        else if (component==1) {
            이미지뷰.image = imageArray[row]
        }
        
    }

}

